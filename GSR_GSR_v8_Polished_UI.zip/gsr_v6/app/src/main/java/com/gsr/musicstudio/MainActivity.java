package com.gsr.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,8,12), SURFACE=Color.rgb(18,17,25), SURFACE2=Color.rgb(24,22,37);
    private final int TEXT=Color.rgb(248,247,252), MUTED=Color.rgb(158,154,173), PURPLE=Color.rgb(132,105,255), PURPLE2=Color.rgb(92,70,215), GREEN=Color.rgb(67,211,145), RED=Color.rgb(239,91,111);
    private LinearLayout root, content;
    private MediaRecorder recorder;
    private MediaPlayer player, studioPlayer;
    private File recordingFile;
    private boolean recording=false;
    private final Handler handler=new Handler();
    private long startMs, studioDurationMs=0;
    private TextView timer, recordStatus, studioPlay, studioTime;
    private SeekBar studioVocal, studioMusic, studioReverb;
    private String selectedStyle="Bollywood", selectedLanguage="Hindi";
    private final String[] styles={"Bollywood","Romantic","Sad","Rock","Lo-fi","Rap","Devotional","EDM"};
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("gsr",MODE_PRIVATE);
        setupSystemBars();
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
        showHome();
    }

    private void setupSystemBars(){
        Window w=getWindow();
        w.setStatusBarColor(BG); w.setNavigationBarColor(BG);
        w.getDecorView().setSystemUiVisibility(0);
        w.getDecorView().setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars());
            if(root!=null) root.setPadding(0,i.top,0,i.bottom);
            return insets;
        });
    }

    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams lp(int w,int h,float weight){return new LinearLayout.LayoutParams(w,h,weight);}
    private void gap(int h){Space s=new Space(this);content.addView(s,lp(1,dp(h)));}

    private TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setFontFeatureSettings("kern");
        return t;
    }
    private GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)radius));return g;}
    private GradientDrawable strokeBg(int fill,int stroke,float radius){GradientDrawable g=bg(fill,radius);g.setStroke(dp(1),stroke);return g;}

    private TextView button(String label,boolean primary){
        TextView t=text(label,15,TEXT);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),0,dp(12),0);t.setMinHeight(dp(50));
        t.setBackground(primary?bg(PURPLE,18):strokeBg(SURFACE2,Color.rgb(66,56,106),18));
        t.setClickable(true);t.setFocusable(true);return t;
    }

    private void base(String subtitle,int selectedTab){
        stopStudioPlayer();
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setClipToPadding(false);

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(18),dp(12),dp(18),dp(8));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=text("GSR",28,TEXT);logo.setTypeface(null,1);brand.addView(logo,lp(-2,dp(30)));
        TextView sub=text(subtitle,9,MUTED);sub.setLetterSpacing(.18f);brand.addView(sub,lp(-2,dp(17)));
        header.addView(brand,lp(0,dp(55),1));
        TextView gear=text("⚙",21,MUTED);gear.setGravity(Gravity.CENTER);gear.setBackground(strokeBg(SURFACE,Color.rgb(52,48,68),30));header.addView(gear,lp(dp(44),dp(44)));
        root.addView(header,lp(-1,dp(67)));

        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setClipToPadding(false);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(28));sv.addView(content);
        root.addView(sv,lp(-1,0,1));

        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(8),dp(6),dp(8),dp(6));nav.setBackgroundColor(Color.rgb(12,11,17));
        String[] icons={"⌂","●","✦","♫"};String[] labels={"Home","Record","Create","Songs"};
        for(int i=0;i<4;i++){final int n=i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(0,dp(2),0,dp(2));
            TextView ic=text(icons[i],19,n==selectedTab?TEXT:MUTED);ic.setGravity(Gravity.CENTER);item.addView(ic,lp(-1,dp(24)));
            TextView lb=text(labels[i],10,n==selectedTab?TEXT:MUTED);lb.setGravity(Gravity.CENTER);item.addView(lb,lp(-1,dp(19)));
            item.setBackground(n==selectedTab?strokeBg(Color.rgb(28,25,47),Color.rgb(62,52,101),16):bg(Color.TRANSPARENT,16));
            item.setOnClickListener(v->{if(n==0)showHome();else if(n==1)showRecord();else if(n==2)showCreate();else showSongs();});
            nav.addView(item,lp(0,dp(56),1));
        }
        root.addView(nav,lp(-1,dp(68)));setContentView(root);root.requestApplyInsets();
    }

    private void eyebrow(String s){TextView t=text(s,10,MUTED);t.setLetterSpacing(.18f);t.setPadding(0,dp(4),0,dp(5));content.addView(t,lp(-1,dp(28)));}
    private void heading(String s,float size){TextView h=text(s,size,TEXT);h.setTypeface(null,1);h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);h.setLineSpacing(0,.92f);content.addView(h,lp(-1,dp((int)(size*2.0f))));}
    private void addCard(View v,int h){content.addView(v,lp(-1,dp(h)));}

    private LinearLayout card(int color,int radius){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(bg(color,radius));c.setPadding(dp(16),dp(14),dp(16),dp(14));return c;}
    private TextView cardTitle(String s){TextView t=text(s,16,TEXT);t.setTypeface(null,1);return t;}
    private TextView cardSub(String s){return text(s,12,MUTED);}

    private void showHome(){
        base("MUSIC STUDIO",0);
        eyebrow("CREATE SOMETHING REAL");
        heading("Your voice.\nYour song.",37);
        TextView intro=text("Turn an idea into a track — starting with your voice.",14,MUTED);content.addView(intro,lp(-1,dp(40)));

        LinearLayout hero=card(SURFACE2,24);
        TextView badge=text("GSR  •  MUSIC CREATOR",10,Color.rgb(185,174,255));badge.setLetterSpacing(.12f);hero.addView(badge,lp(-1,dp(22)));
        TextView ht=cardTitle("Start with a vocal");hero.addView(ht,lp(-1,dp(30)));
        hero.addView(cardSub("Record a clean vocal, then build your song around it."),lp(-1,dp(28)));
        TextView rec=button("🎙   Record a vocal",true);hero.addView(rec,lp(-1,dp(54)));rec.setOnClickListener(v->showRecord());
        addCard(hero,dp(176));

        eyebrow("QUICK CREATE");
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);
        LinearLayout make=miniAction("✦","Make a song","Style + idea");LinearLayout lyr=miniAction("♫","Write lyrics","Start from words");row.addView(make,lp(0,dp(110),1));row.addView(lyr,lp(0,dp(110),1));content.addView(row,lp(-1,dp(116)));
        make.setOnClickListener(v->showCreate());lyr.setOnClickListener(v->showCreate());

        eyebrow("RECENT PROJECT");
        String last=prefs.getString("lastSong","");
        if(last.isEmpty()){
            LinearLayout empty=card(SURFACE,18);empty.setGravity(Gravity.CENTER_VERTICAL);
            TextView e1=cardTitle("No projects yet");empty.addView(e1,lp(-1,dp(27)));empty.addView(cardSub("Your first song will appear here."),lp(-1,dp(24)));content.addView(empty,lp(-1,dp(74)));
        }else{
            LinearLayout recent=card(SURFACE,18);recent.setGravity(Gravity.CENTER_VERTICAL);TextView title=cardTitle("♫  "+last);recent.addView(title,lp(-1,dp(27)));recent.addView(cardSub("Tap to open your studio"),lp(-1,dp(24)));recent.setClickable(true);recent.setOnClickListener(v->showStudio(last));content.addView(recent,lp(-1,dp(74)));
        }
        gap(14);
        TextView tip=text("Tip  •  Record in a quiet room for a cleaner vocal.",11,MUTED);tip.setGravity(Gravity.CENTER);content.addView(tip,lp(-1,dp(38)));
    }

    private LinearLayout miniAction(String icon,String title,String sub){LinearLayout c=card(SURFACE,20);c.setGravity(Gravity.CENTER_VERTICAL);TextView i=text(icon,22,Color.rgb(186,173,255));i.setGravity(Gravity.CENTER);c.addView(i,lp(-1,dp(28)));TextView t=cardTitle(title);t.setTextSize(14);t.setGravity(Gravity.CENTER);c.addView(t,lp(-1,dp(24)));TextView s=cardSub(sub);s.setTextSize(10);s.setGravity(Gravity.CENTER);c.addView(s,lp(-1,dp(20)));return c;}

    private void showRecord(){
        base("GSR STUDIO",1);TextView back=button("‹  Back",false);back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);content.addView(back,lp(dp(100),dp(46)));back.setOnClickListener(v->showHome());
        eyebrow("VOCAL RECORDING");heading("Capture your\nvoice.",35);
        LinearLayout card=card(SURFACE2,24);card.setGravity(Gravity.CENTER);TextView wave=text("▁▂▃▅▇▅▃▂▁▂▃▅▇▅▃▂▁",20,Color.rgb(154,130,255));wave.setGravity(Gravity.CENTER);card.addView(wave,lp(-1,dp(42)));
        timer=text("00:00.00",31,TEXT);timer.setGravity(Gravity.CENTER);card.addView(timer,lp(-1,dp(48)));
        TextView rec=button("●",false);rec.setTextSize(30);rec.setTextColor(RED);rec.setBackground(strokeBg(Color.rgb(32,20,27),Color.rgb(105,48,63),52));card.addView(rec,lp(dp(92),dp(92)));((LinearLayout.LayoutParams)rec.getLayoutParams()).gravity=Gravity.CENTER;
        recordStatus=text(recordingFile!=null&&recordingFile.exists()?"Recording ready":"Tap the button to start",12,MUTED);recordStatus.setGravity(Gravity.CENTER);card.addView(recordStatus,lp(-1,dp(34)));content.addView(card,lp(-1,dp(285)));rec.setOnClickListener(v->toggleRecording());
        if(recordingFile!=null&&recordingFile.exists()){gap(12);TextView play=button("▶   Play last recording",false);content.addView(play,lp(-1,dp(54)));play.setOnClickListener(v->playRecording());gap(10);TextView use=button("Use this vocal   →",true);content.addView(use,lp(-1,dp(56)));use.setOnClickListener(v->showCreate());}
    }

    private void toggleRecording(){
        if(recording){stopRecording();return;}
        if(android.os.Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);return;}
        recordingFile=new File(getExternalFilesDir(null),"GSR_Vocal_"+System.currentTimeMillis()+".m4a");
        recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioEncodingBitRate(192000);recorder.setAudioSamplingRate(44100);recorder.setOutputFile(recordingFile.getAbsolutePath());
        try{recorder.prepare();recorder.start();recording=true;startMs=System.currentTimeMillis();recordStatus.setText("Recording… tap again to stop");tick();}catch(Exception e){recording=false;Toast.makeText(this,"Microphone could not start",Toast.LENGTH_LONG).show();}
    }
    private void tick(){if(!recording)return;long x=System.currentTimeMillis()-startMs;timer.setText(String.format("%02d:%02d.%02d",(x/60000)%60,(x/1000)%60,(x/10)%100));handler.postDelayed(this::tick,50);}
    private void stopRecording(){try{recorder.stop();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}recorder=null;recording=false;recordStatus.setText("Recording complete");showRecord();}
    private void playRecording(){if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"No recording found",Toast.LENGTH_SHORT).show();return;}try{if(player!=null)player.release();player=new MediaPlayer();player.setDataSource(recordingFile.getAbsolutePath());player.prepare();player.start();}catch(Exception e){Toast.makeText(this,"Unable to play recording",Toast.LENGTH_SHORT).show();}}

    private void showCreate(){
        base("BUILD YOUR TRACK",2);TextView back=button("‹  Back",false);back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);content.addView(back,lp(dp(100),dp(46)));back.setOnClickListener(v->{hideKeyboard();showHome();});
        eyebrow("AI SONG BUILDER");heading("What should\nit sound like?",35);
        eyebrow("LANGUAGE");LinearLayout langs=new LinearLayout(this);langs.setOrientation(LinearLayout.HORIZONTAL);langs.setGravity(Gravity.CENTER);content.addView(langs,lp(-1,dp(60)));
        for(String s:new String[]{"Hindi","English","Hinglish"}){TextView b=button(s,false);langs.addView(b,lp(0,dp(52),1));b.setOnClickListener(v->{selectedLanguage=s;updateSelection(langs);});}updateSelection(langs);
        eyebrow("STYLE");
        for(int i=0;i<styles.length;i+=2){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);content.addView(row,lp(-1,dp(62)));for(int j=i;j<i+2&&j<styles.length;j++){String s=styles[j];TextView b=button("♪  "+s,false);row.addView(b,lp(0,dp(54),1));b.setOnClickListener(v->{selectedStyle=s;Toast.makeText(this,s+" selected",Toast.LENGTH_SHORT).show();});}}
        eyebrow("SONG IDEA  •  OPTIONAL");EditText idea=new EditText(this);idea.setHint("Describe your song idea…");idea.setHintTextColor(Color.rgb(110,106,125));idea.setTextColor(TEXT);idea.setTextSize(16);idea.setSingleLine(false);idea.setMinLines(4);idea.setMaxLines(6);idea.setGravity(Gravity.TOP|Gravity.LEFT);idea.setPadding(dp(16),dp(14),dp(16),dp(14));idea.setBackground(strokeBg(SURFACE,Color.rgb(58,51,82),18));idea.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);content.addView(idea,lp(-1,dp(118)));
        idea.setOnFocusChangeListener((v,has)->{if(has)content.postDelayed(()->{ViewGroup p=(ViewGroup)content.getParent();if(p instanceof ScrollView)((ScrollView)p).smoothScrollTo(0,Math.max(0,idea.getBottom()-dp(300)));},250);});
        gap(12);TextView make=button("✦   CREATE MY SONG",true);content.addView(make,lp(-1,dp(58)));make.setOnClickListener(v->createSongFromIdea(idea));
        TextView note=text("You can change the language and style before creating.",11,MUTED);note.setGravity(Gravity.CENTER);content.addView(note,lp(-1,dp(36)));gap(22);
    }
    private void createSongFromIdea(EditText idea){String title=idea.getText().toString().trim();if(title.isEmpty())title="My New Song";if(title.length()>45)title=title.substring(0,45).trim();prefs.edit().putString("lastSong",title).apply();hideKeyboard();idea.clearFocus();showStudio(title);}
    private void hideKeyboard(){try{InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);View v=getCurrentFocus();if(v!=null)imm.hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}
    private void updateSelection(LinearLayout row){for(int i=0;i<row.getChildCount();i++){TextView b=(TextView)row.getChildAt(i);String s=b.getText().toString();b.setBackground(s.equals(selectedLanguage)?strokeBg(Color.rgb(31,27,52),PURPLE,18):strokeBg(SURFACE2,Color.rgb(66,56,106),18));}}

    private void showStudio(String title){
        base("GSR STUDIO",3);TextView back=button("‹  Back",false);back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);content.addView(back,lp(dp(100),dp(46)));back.setOnClickListener(v->showCreate());
        eyebrow("PROJECT");heading(title,29);TextView meta=text(selectedStyle.toUpperCase()+"  •  "+selectedLanguage+"  •  96 BPM",10,MUTED);content.addView(meta,lp(-1,dp(25)));
        LinearLayout cover=card(SURFACE2,24);cover.setGravity(Gravity.CENTER);TextView g=text("GSR",25,TEXT);g.setTypeface(null,1);g.setGravity(Gravity.CENTER);cover.addView(g,lp(-1,dp(42)));TextView sub=text(recordingFile!=null&&recordingFile.exists()?"VOCAL READY":"RECORD A VOCAL FIRST",13,recordingFile!=null&&recordingFile.exists()?GREEN:MUTED);sub.setGravity(Gravity.CENTER);cover.addView(sub,lp(-1,dp(30)));content.addView(cover,lp(-1,dp(142)));
        gap(10);studioPlay=button("▶   PLAY VOCAL",true);content.addView(studioPlay,lp(-1,dp(56)));studioPlay.setOnClickListener(v->playStudio());studioTime=text("00:00 / --:--",11,MUTED);studioTime.setGravity(Gravity.CENTER);content.addView(studioTime,lp(-1,dp(27)));
        eyebrow("TRACKS");addTrack("🎙  VOCAL","Your recorded voice",true);addTrack("♫  MUSIC","Instrumental arrangement",false);addTrack("🥁  BEAT","Drums / rhythm",false);
        eyebrow("MIX");addMixer("VOCAL",82,true);addMixer("MUSIC",68,false);addMixer("REVERB",28,false);gap(8);TextView ex=button("↓   EXPORT SONG",true);content.addView(ex,lp(-1,dp(58)));ex.setOnClickListener(v->exportSong(title));
    }
    private void addTrack(String name,String sub,boolean active){LinearLayout c=card(SURFACE,18);c.setGravity(Gravity.CENTER_VERTICAL);TextView n=cardTitle(name);c.addView(n,lp(-1,dp(26)));TextView s=cardSub(sub);s.setTextColor(active?MUTED:Color.rgb(105,101,119));c.addView(s,lp(-1,dp(22)));content.addView(c,lp(-1,dp(64)));}
    private void addMixer(String label,int value,boolean vocal){content.addView(text(label,10,MUTED),lp(-1,dp(22)));SeekBar s=new SeekBar(this);s.setProgress(value);content.addView(s,lp(-1,dp(34)));if(vocal)studioVocal=s;else if(studioMusic==null)studioMusic=s;else studioReverb=s;if(vocal)s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){applyStudioVolume();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});}
    private void playStudio(){if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"Record your vocal first.",Toast.LENGTH_LONG).show();return;}try{if(studioPlayer==null){studioPlayer=new MediaPlayer();studioPlayer.setDataSource(recordingFile.getAbsolutePath());studioPlayer.setOnPreparedListener(mp->{studioDurationMs=mp.getDuration();applyStudioVolume();mp.start();updateStudio();});studioPlayer.setOnCompletionListener(mp->updateStudio());studioPlayer.prepareAsync();studioPlay.setText("…  LOADING AUDIO");}else if(studioPlayer.isPlaying()){studioPlayer.pause();updateStudio();}else{studioPlayer.start();updateStudio();}}catch(Exception e){Toast.makeText(this,"Unable to play song",Toast.LENGTH_SHORT).show();stopStudioPlayer();}}
    private void updateStudio(){if(studioPlay==null)return;boolean playing=false;long pos=0;try{playing=studioPlayer!=null&&studioPlayer.isPlaying();if(studioPlayer!=null)pos=studioPlayer.getCurrentPosition();}catch(Exception ignored){}studioPlay.setText(playing?"❚❚   PAUSE":"▶   PLAY VOCAL");String a=String.format("%02d:%02d",(pos/60000)%60,(pos/1000)%60);String b=studioDurationMs>0?String.format("%02d:%02d",(studioDurationMs/60000)%60,(studioDurationMs/1000)%60):"--:--";if(studioTime!=null)studioTime.setText(a+" / "+b);if(playing)handler.postDelayed(this::updateStudio,250);}
    private void applyStudioVolume(){if(studioPlayer==null)return;try{float v=(studioVocal==null?82:studioVocal.getProgress())/100f;studioPlayer.setVolume(v,v);}catch(Exception ignored){}}
    private void stopStudioPlayer(){if(studioPlayer!=null){try{studioPlayer.stop();}catch(Exception ignored){}try{studioPlayer.release();}catch(Exception ignored){}studioPlayer=null;}}

    private void exportSong(String name){if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"Please record a vocal first.",Toast.LENGTH_LONG).show();return;}String safe=name==null?"My New Song":name.replaceAll("[^a-zA-Z0-9 _-]","").trim();if(safe.isEmpty())safe="My New Song";String fn=safe+".m4a";try{if(android.os.Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.DISPLAY_NAME,fn);v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mp4");v.put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/GSR");Uri u=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("media file unavailable");try(InputStream in=new FileInputStream(recordingFile);OutputStream out=getContentResolver().openOutputStream(u)){byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}else{File dir=new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MUSIC),"GSR");dir.mkdirs();try(InputStream in=new FileInputStream(recordingFile);OutputStream out=new FileOutputStream(new File(dir,fn))){byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}Toast.makeText(this,"Saved in Music/GSR/"+fn,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    private void showSongs(){base("YOUR PROJECTS",3);eyebrow("RECENT PROJECTS");String last=prefs.getString("lastSong","");if(last.isEmpty()){heading("No songs yet.",28);content.addView(text("Record a vocal or create your first song to see it here.",14,MUTED),lp(-1,dp(50)));}else{heading("Your music.",29);LinearLayout p=card(SURFACE,18);p.addView(cardTitle("♫  "+last),lp(-1,dp(27)));p.addView(cardSub("Open in GSR Studio"),lp(-1,dp(24)));p.setOnClickListener(v->showStudio(last));content.addView(p,lp(-1,dp(74)));}gap(14);TextView rec=button("🎙   RECORD NEW VOCAL",true);content.addView(rec,lp(-1,dp(58)));rec.setOnClickListener(v->showRecord());}

    @Override protected void onDestroy(){super.onDestroy();handler.removeCallbacksAndMessages(null);if(recording){try{recorder.stop();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}}if(player!=null)try{player.release();}catch(Exception ignored){}stopStudioPlayer();}
}
