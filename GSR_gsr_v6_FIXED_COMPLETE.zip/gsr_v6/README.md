# GSR Music Studio - Android Project (v7 FIXED)

This is the corrected native Android Studio project for GSR Music Studio.

## Main fix
The previous GitHub Actions build failed in `MainActivity.java` because `WindowInsets.Type.systemBars()` returns an integer bitmask. The corrected code uses:

```java
int t = WindowInsets.Type.systemBars();
android.graphics.Insets i = insets.getInsets(t);
```

## Features currently included
- Native Android Java application
- Vocal recording using the phone microphone
- AAC/M4A recording at 44.1 kHz / 192 kbps
- Playback of the latest vocal recording
- Hindi / English / Hinglish selection
- Bollywood / Romantic / Sad / Rock / Lo-fi / Rap / Devotional / EDM styles
- Song idea input
- GSR studio screen
- Vocal / Music / Beat tracks
- Vocal/Music/Reverb mixer controls
- Export recording to `Music/GSR`
- GitHub Actions workflow for debug APK

## GitHub build
The repository should contain the **extracted contents** of this project, not the ZIP file itself. The included workflow builds `gsr_v6/app` and uploads `GSR.apk` as the `GSR-Android-APK` artifact.

## Important
This version does not yet generate AI instrumental music. The Music and Beat tracks are UI placeholders around the recorded vocal. AI music generation and true multi-track mixing can be added in the next version.
