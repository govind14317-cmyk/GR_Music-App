GSR Music Studio v1.1

Native Android Studio project.

UI improvements:
- Android 15 status/navigation insets handled
- No clipped buttons or text
- Scrollable screens
- Proper home, record, create, studio and projects navigation
- Real microphone recording and playback
- Vocal mixer volume control
- Export recorded vocal to Music/GSR
- Recent project persistence

Note: Music, Beat, Reverb and AI generation are currently UI-ready placeholders. The next audio-engine phase can add generated instrumentals and real multi-track mixing.
