GSR MUSIC STUDIO — NATIVE ANDROID V1

This is a real native Android Studio project, not a browser/PWA.

Current V1:
- Native Android UI
- GSR branded home screen
- Microphone permission
- Real voice recording to M4A/AAC at 44.1 kHz / 192 kbps
- Recording timer
- Playback of last recording
- Language selection
- Music-style selection
- Song idea input
- Multi-track studio UI
- Vocal/music/reverb mixer controls
- Android portrait layout

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect your Android phone with USB debugging enabled.
4. Run the app.
5. Grant microphone permission.

The app records audio using Android's native audio APIs and requires RECORD_AUDIO permission.
AI music generation is intentionally the next backend stage; the native shell is ready for it.
