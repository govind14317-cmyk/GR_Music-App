package com.gsr.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends Activity {
    int bg=Color.rgb(9,9,13), panel=Color.rgb(18,18,24), text=Color.rgb(247,246,250),
        muted=Color.rgb(140,138,152), purple=Color.rgb(125,107,255), red=Color.rgb(232,93,115);
    LinearLayout root, content;
    MediaRecorder recorder; MediaPlayer player; File recordingFile;
    MediaPlayer studioPlayer;
    SeekBar studioVocal, studioMusic, studioReverb;
    Button studioPlay;
    long studioDurationMs=0;
    boolean recording=false;
    Handler handler=new Handler(); long startMs;
    TextView timer, status;
    String selectedStyle="Bollywood";
    String[] styles={"Bollywood","Romantic","Sad","Rock","Lo-fi","Rap","Devotional","EDM"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
        showHome();
    }

    TextView tv(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(0,4,0,4); return t;
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(text); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundResource(com.gsr.musicstudio.R.drawable.bg_button); return b; }
    void base(String title,String subtitle){
        stopStudioPlayer();
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        LinearLayout top=new LinearLayout(this); top.setPadding(22,18,22,12); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv("GSR",27,text); a.setTypeface(null,1); brand.addView(a);
        brand.addView(tv(subtitle,9,muted));
        top.addView(brand,new LinearLayout.LayoutParams(0,70,1));
        TextView gear=tv("⚙",23,muted); gear.setGravity(Gravity.CENTER); top.addView(gear,new LinearLayout.LayoutParams(48,70));
        root.addView(top);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(22,8,22,22);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.rgb(13,13,18));
        String[] n={"⌂\nHOME","●\nRECORD","✦\nCREATE","♫\nSONGS"};
        for(String x:n){ Button nb=btn(x); nb.setTextColor(muted); nav.addView(nb,new LinearLayout.LayoutParams(0,76,1)); }
        ((Button)nav.getChildAt(0)).setOnClickListener(v->showHome());
        ((Button)nav.getChildAt(1)).setOnClickListener(v->showRecord());
        ((Button)nav.getChildAt(2)).setOnClickListener(v->showCreate());
        ((Button)nav.getChildAt(3)).setOnClickListener(v->showSongs());
        root.addView(nav,new LinearLayout.LayoutParams(-1,78));
        setContentView(root);
    }
    TextView heading(String s){ TextView h=tv(s,38,text); h.setTypeface(null,1); h.setPadding(0,22,0,10); content.addView(h); return h; }
    TextView section(String s){ TextView h=tv(s,10,muted); h.setLetterSpacing(.12f); h.setPadding(0,24,0,10); content.addView(h); return h; }

    void showHome(){
        base("","MUSIC STUDIO");
        TextView pre=tv("CREATE SOMETHING REAL",10,muted); pre.setLetterSpacing(.2f); content.addView(pre);
        TextView h=heading("Your voice.\nYour song."); h.setTextSize(42);
        TextView p=tv("Record your voice and build a complete track around it.",15,muted); content.addView(p);
        Button r=btn("🎙   Record a vocal\n      Start a new recording"); r.setTextSize(16); content.addView(r,new LinearLayout.LayoutParams(-1,82));
        r.setOnClickListener(v->showRecord());
        section("CREATE WITH AI");
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button a=btn("✦  Make a Song\n    Voice + music"), c=btn("♫  Write Lyrics\n    AI songwriting");
        row.addView(a,new LinearLayout.LayoutParams(0,78,1)); row.addView(c,new LinearLayout.LayoutParams(0,78,1));
        content.addView(row); a.setOnClickListener(v->showCreate()); c.setOnClickListener(v->showCreate());
        section("RECENT PROJECTS");
        content.addView(tv("No songs yet — create your first track.",14,muted));
    }

    void showRecord(){
        base("","GSR STUDIO");
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=btn("‹"); head.addView(back,new LinearLayout.LayoutParams(55,55)); back.setOnClickListener(v->showHome());
        TextView t=tv("VOCAL RECORDING\nGSR STUDIO",12,text); t.setGravity(Gravity.CENTER); head.addView(t,new LinearLayout.LayoutParams(0,55,1));
        content.addView(head);
        TextView h=heading("Capture your\nvoice."); h.setTextSize(38);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(20,28,20,28); card.setBackgroundResource(R.drawable.bg_panel);
        TextView wave=tv("▁▂▃▅▇▅▃▂▁▂▃▅▇▅▃▂▁",23,purple); wave.setGravity(Gravity.CENTER); card.addView(wave);
        timer=tv("00:00.00",32,text); timer.setGravity(Gravity.CENTER); card.addView(timer);
        Button rec=btn("●"); rec.setTextSize(32); rec.setBackgroundResource(R.drawable.bg_record);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(100,100); rp.gravity=Gravity.CENTER; rp.topMargin=22; card.addView(rec,rp);
        status=tv("Tap to start recording",13,muted); status.setGravity(Gravity.CENTER); card.addView(status);
        content.addView(card,new LinearLayout.LayoutParams(-1,300)); rec.setOnClickListener(v->toggleRecording());
        if(recordingFile!=null && recordingFile.exists()){
            Button play=btn("▶  Play last recording"); content.addView(play); play.setOnClickListener(v->playRecording());
        }
        Button use=btn("Use this vocal  →"); use.setBackgroundResource(R.drawable.bg_purple); use.setTextColor(Color.WHITE);
        content.addView(use,new LinearLayout.LayoutParams(-1,62)); use.setOnClickListener(v->showCreate());
    }

    void toggleRecording(){
        if(recording){ stopRecording(); return; }
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77); return;
        }
        recordingFile=new File(getExternalFilesDir(null),"GSR_Vocal_"+System.currentTimeMillis()+".m4a");
        recorder=new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        recorder.setAudioEncodingBitRate(192000);
        recorder.setAudioSamplingRate(44100);
        recorder.setOutputFile(recordingFile.getAbsolutePath());
        try{recorder.prepare();recorder.start();recording=true;startMs=System.currentTimeMillis();status.setText("Recording… tap to stop");tick();}catch(Exception e){status.setText("Could not start microphone");}
    }
    void tick(){if(!recording)return;long x=System.currentTimeMillis()-startMs;timer.setText(String.format("%02d:%02d.%02d",(x/60000)%60,(x/1000)%60,(x/10)%100));handler.postDelayed(this::tick,50);}
    void stopRecording(){try{recorder.stop();}catch(Exception ignored){}recorder.release();recorder=null;recording=false;status.setText("Recording complete");showRecord();}
    void playRecording(){
        if(recordingFile==null || !recordingFile.exists()){ Toast.makeText(this,"No recording found",Toast.LENGTH_SHORT).show(); return; }
        try{
            if(player!=null) player.release();
            player=new MediaPlayer();
            player.setDataSource(recordingFile.getAbsolutePath());
            player.prepare();
            player.start();
        }catch(Exception e){ Toast.makeText(this,"Unable to play recording",Toast.LENGTH_SHORT).show(); }
    }

    void stopStudioPlayer(){
        if(studioPlayer!=null){
            try{ if(studioPlayer.isPlaying()) studioPlayer.stop(); }catch(Exception ignored){}
            try{ studioPlayer.release(); }catch(Exception ignored){}
            studioPlayer=null;
        }
    }

    void playStudio(){
        if(recordingFile==null || !recordingFile.exists()){
            Toast.makeText(this,"Record your vocal first, then build the song.",Toast.LENGTH_LONG).show();
            return;
        }
        try{
            if(studioPlayer==null){
                studioPlayer=new MediaPlayer();
                studioPlayer.setDataSource(recordingFile.getAbsolutePath());
                studioPlayer.setOnPreparedListener(mp -> {
                    studioDurationMs=mp.getDuration();
                    updateStudioPlayButton();
                    mp.start();
                });
                studioPlayer.setOnCompletionListener(mp -> updateStudioPlayButton());
                studioPlayer.prepareAsync();
            }else if(studioPlayer.isPlaying()){
                studioPlayer.pause();
            }else{
                studioPlayer.start();
            }
            updateStudioPlayButton();
        }catch(Exception e){
            Toast.makeText(this,"Unable to play song",Toast.LENGTH_SHORT).show();
            stopStudioPlayer();
        }
    }

    void updateStudioPlayButton(){
        if(studioPlay==null) return;
        boolean playing=false;
        try{ playing=studioPlayer!=null && studioPlayer.isPlaying(); }catch(Exception ignored){}
        String time="00:00";
        try{
            if(studioPlayer!=null){
                long ms=studioPlayer.getCurrentPosition();
                time=String.format("%02d:%02d",(ms/60000)%60,(ms/1000)%60);
            }
        }catch(Exception ignored){}
        String total="--:--";
        if(studioDurationMs>0) total=String.format("%02d:%02d",(studioDurationMs/60000)%60,(studioDurationMs/1000)%60);
        studioPlay.setText((playing?"❚❚":"▶")+"   "+time+"        "+total);
    }

    void applyStudioVolume(){
        if(studioPlayer==null) return;
        float vocal=studioVocal==null?1f:studioVocal.getProgress()/100f;
        try{ studioPlayer.setVolume(vocal,vocal); }catch(Exception ignored){}
    }

    void exportSong(String songName){
        if(recordingFile==null || !recordingFile.exists()){
            Toast.makeText(this,"Please record a vocal first.",Toast.LENGTH_LONG).show();
            return;
        }
        String safe=songName==null||songName.trim().isEmpty()?"My New Song":songName.trim();
        safe=safe.replaceAll("[^a-zA-Z0-9 _-]","").trim();
        if(safe.isEmpty()) safe="My New Song";
        String fileName=safe+".m4a";
        try{
            if(android.os.Build.VERSION.SDK_INT>=29){
                ContentValues values=new ContentValues();
                values.put(MediaStore.Audio.Media.DISPLAY_NAME,fileName);
                values.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mp4");
                values.put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/GSR");
                Uri uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values);
                if(uri==null) throw new IOException("Could not create media file");
                try(InputStream in=new java.io.FileInputStream(recordingFile); OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null) throw new IOException("Could not open output");
                    byte[] buf=new byte[8192]; int n;
                    while((n=in.read(buf))!=-1) out.write(buf,0,n);
                }
            }else{
                File music=new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MUSIC),"GSR");
                if(!music.exists()) music.mkdirs();
                File outFile=new File(music,fileName);
                try(InputStream in=new java.io.FileInputStream(recordingFile); OutputStream out=new java.io.FileOutputStream(outFile)){
                    byte[] buf=new byte[8192]; int n;
                    while((n=in.read(buf))!=-1) out.write(buf,0,n);
                }
            }
            Toast.makeText(this,"Exported to Music/GSR/"+fileName,Toast.LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    void showCreate(){
        base("","BUILD YOUR TRACK");
        Button back=btn("‹  Back"); content.addView(back,new LinearLayout.LayoutParams(90,52)); back.setOnClickListener(v->showHome());
        TextView h=heading("What should\nit sound like?"); h.setTextSize(38);
        section("LANGUAGE");
        LinearLayout lang=new LinearLayout(this); String[] ls={"Hindi","English","Hinglish"};
        for(String s:ls){Button b=btn(s); lang.addView(b,new LinearLayout.LayoutParams(0,58,1));} content.addView(lang);
        section("STYLE");
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2);
        for(String s:styles){Button b=btn("♪  "+s); b.setOnClickListener(v->{selectedStyle=s; Toast.makeText(this,s+" selected",Toast.LENGTH_SHORT).show();}); grid.addView(b,new ViewGroup.LayoutParams(-1,72));}
        content.addView(grid);
        section("SONG IDEA  •  OPTIONAL");
        EditText idea=new EditText(this); idea.setHint("Example: a motivational song about achieving dreams…"); idea.setHintTextColor(muted); idea.setTextColor(text); idea.setMinHeight(100); idea.setGravity(Gravity.TOP); content.addView(idea);
        Button make=btn("✦  BUILD MY SONG"); make.setBackgroundResource(R.drawable.bg_purple); make.setTextColor(Color.WHITE); content.addView(make,new LinearLayout.LayoutParams(-1,64));
        make.setOnClickListener(v->{Toast.makeText(this,"Creating "+selectedStyle+" song…",Toast.LENGTH_SHORT).show();showStudio(idea.getText().toString());});
    }

    void showStudio(String idea){
        base("","GSR STUDIO");
        Button back=btn("‹"); content.addView(back,new LinearLayout.LayoutParams(60,55)); back.setOnClickListener(v->showCreate());
        TextView h=heading(idea.length()>0?idea.toString():"My New Song"); h.setTextSize(28);
        TextView meta=tv(selectedStyle.toUpperCase()+"  •  96 BPM",10,muted); content.addView(meta);
        TextView cover=tv("GSR\n\nVOCAL + INSTRUMENTAL",28,text); cover.setGravity(Gravity.CENTER); cover.setBackgroundResource(R.drawable.bg_button); content.addView(cover,new LinearLayout.LayoutParams(-1,210));
        studioPlay=btn("▶   00:00        --:--"); content.addView(studioPlay,new LinearLayout.LayoutParams(-1,65));
        studioPlay.setOnClickListener(v->playStudio());
        section("MULTI-TRACK");
        addTrack("🎙  VOCAL","Your recorded voice");
        addTrack("♫  MUSIC","Instrumental arrangement — ready for AI music");
        addTrack("🥁  BEAT","Drums / rhythm — ready for AI beat");
        section("MIX");
        content.addView(tv("VOCAL",10,muted)); studioVocal=new SeekBar(this);studioVocal.setProgress(82);content.addView(studioVocal);
        content.addView(tv("MUSIC",10,muted)); studioMusic=new SeekBar(this);studioMusic.setProgress(68);content.addView(studioMusic);
        content.addView(tv("REVERB",10,muted)); studioReverb=new SeekBar(this);studioReverb.setProgress(28);content.addView(studioReverb);
        studioVocal.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){applyStudioVolume();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        Button ex=btn("↓  EXPORT SONG"); ex.setBackgroundResource(R.drawable.bg_purple);ex.setTextColor(Color.WHITE);content.addView(ex,new LinearLayout.LayoutParams(-1,64));
        ex.setOnClickListener(v->exportSong(idea));
    }
    void addTrack(String name,String sub){LinearLayout x=new LinearLayout(this);x.setPadding(15,12,15,12);x.setBackgroundResource(R.drawable.bg_panel);x.setOrientation(LinearLayout.VERTICAL);x.addView(tv(name,13,text));x.addView(tv(sub,10,muted));content.addView(x,new LinearLayout.LayoutParams(-1,72));}
    void showSongs(){base("","YOUR PROJECTS");content.addView(tv("No projects yet.",18,muted));}
}