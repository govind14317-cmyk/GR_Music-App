package com.gsr.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    final int bg=Color.rgb(9,9,13), panel=Color.rgb(18,18,24), text=Color.rgb(247,246,250),
            muted=Color.rgb(155,152,166), purple=Color.rgb(125,107,255);
    LinearLayout root, content;
    MediaRecorder recorder; MediaPlayer player; File recordingFile;
    boolean recording=false;
    Handler handler=new Handler(); long startMs;
    TextView timer, status;
    String selectedStyle="Bollywood";
    String[] styles={"Bollywood","Romantic","Sad","Rock","Lo-fi","Rap","Devotional","EDM"};

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    LinearLayout.LayoutParams lp(int w,int h,float weight){ return new LinearLayout.LayoutParams(w,h,weight); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
        showHome();
    }

    TextView tv(String s,float size,int color){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true); return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(text); b.setTextSize(14); b.setAllCaps(false);
        b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setMinWidth(0); b.setIncludeFontPadding(true);
        b.setPadding(dp(12),dp(8),dp(12),dp(8)); b.setBackgroundResource(R.drawable.bg_button); return b;
    }

    void base(String title,String subtitle){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);

        LinearLayout top=new LinearLayout(this); top.setPadding(dp(18),dp(10),dp(14),dp(4)); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=tv("GSR",26,text); logo.setTypeface(null,1); brand.addView(logo,lp(-1,dp(34)));
        brand.addView(tv(subtitle,9,muted),lp(-1,dp(18)));
        top.addView(brand,lp(0,dp(58),1));
        TextView gear=tv("⚙",22,muted); gear.setGravity(Gravity.CENTER); top.addView(gear,lp(dp(48),dp(58)));
        root.addView(top,lp(-1,dp(72)));

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18),dp(6),dp(18),dp(20));
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.addView(content); root.addView(sv,lp(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(4),dp(4),dp(4)); nav.setBackgroundColor(Color.rgb(13,13,18));
        String[] n={"⌂\nHOME","●\nRECORD","✦\nCREATE","♫\nSONGS"};
        for(String x:n){ Button nb=btn(x); nb.setTextColor(muted); nb.setTextSize(11); nav.addView(nb,lp(0,dp(64),1)); }
        ((Button)nav.getChildAt(0)).setOnClickListener(v->showHome());
        ((Button)nav.getChildAt(1)).setOnClickListener(v->showRecord());
        ((Button)nav.getChildAt(2)).setOnClickListener(v->showCreate());
        ((Button)nav.getChildAt(3)).setOnClickListener(v->showSongs());
        root.addView(nav,lp(-1,dp(72)));
        setContentView(root);
    }

    TextView heading(String s){
        TextView h=tv(s,36,text); h.setTypeface(null,1); h.setPadding(0,dp(18),0,dp(8)); content.addView(h,lp(-1,dp(108))); return h;
    }
    TextView section(String s){
        TextView h=tv(s,10,muted); h.setLetterSpacing(.12f); h.setPadding(0,dp(18),0,dp(8)); content.addView(h,lp(-1,dp(50))); return h;
    }

    void showHome(){
        base("","MUSIC STUDIO");
        TextView pre=tv("CREATE SOMETHING REAL",10,muted); pre.setLetterSpacing(.20f); content.addView(pre,lp(-1,dp(30)));
        TextView h=heading("Your voice.\nYour song."); h.setTextSize(40);
        TextView p=tv("Record your voice and build a complete track around it.",15,muted); p.setPadding(0,0,0,dp(10)); content.addView(p,lp(-1,dp(54)));

        Button r=btn("🎙   Record a vocal\n      Start a new recording"); r.setTextSize(15); r.setGravity(Gravity.CENTER); content.addView(r,lp(-1,dp(68)));
        r.setOnClickListener(v->showRecord());

        section("CREATE WITH AI");
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,0,0,0);
        Button a=btn("✦  Make a Song\n    Voice + music"), c=btn("♫  Write Lyrics\n    AI songwriting");
        a.setTextSize(14); c.setTextSize(14);
        LinearLayout.LayoutParams half=lp(0,dp(76),1); half.rightMargin=dp(5);
        LinearLayout.LayoutParams half2=lp(0,dp(76),1); half2.leftMargin=dp(5);
        row.addView(a,half); row.addView(c,half2); content.addView(row);
        a.setOnClickListener(v->showCreate()); c.setOnClickListener(v->showCreate());

        section("RECENT PROJECTS");
        TextView empty=tv("No songs yet — create your first track.",14,muted); content.addView(empty,lp(-1,dp(48)));
        Space space=new Space(this); content.addView(space,lp(1,dp(120)));
    }

    void showRecord(){
        base("","GSR STUDIO");
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=btn("‹"); head.addView(back,lp(dp(52),dp(52))); back.setOnClickListener(v->showHome());
        TextView t=tv("VOCAL RECORDING",13,text); t.setGravity(Gravity.CENTER); head.addView(t,lp(0,dp(52),1));
        content.addView(head,lp(-1,dp(58)));
        TextView h=heading("Capture your\nvoice."); h.setTextSize(36);

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(18),dp(20),dp(18),dp(20)); card.setBackgroundResource(R.drawable.bg_panel);
        TextView wave=tv("▁▂▃▅▇▅▃▂▁▂▃▅▇▅▃▂▁",22,purple); wave.setGravity(Gravity.CENTER); card.addView(wave,lp(-1,dp(44)));
        timer=tv("00:00.00",30,text); timer.setGravity(Gravity.CENTER); card.addView(timer,lp(-1,dp(54)));
        Button rec=btn("●"); rec.setTextSize(30); rec.setBackgroundResource(R.drawable.bg_record);
        LinearLayout.LayoutParams rp=lp(dp(86),dp(86)); rp.gravity=Gravity.CENTER; rp.topMargin=dp(12); card.addView(rec,rp);
        status=tv("Tap to start recording",13,muted); status.setGravity(Gravity.CENTER); card.addView(status,lp(-1,dp(42)));
        content.addView(card,lp(-1,dp(286))); rec.setOnClickListener(v->toggleRecording());
        if(recordingFile!=null && recordingFile.exists()){
            Button play=btn("▶  Play last recording"); content.addView(play,lp(-1,dp(58))); play.setOnClickListener(v->playRecording());
        }
        Button use=btn("Use this vocal  →"); use.setBackgroundResource(R.drawable.bg_purple); use.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams up=lp(-1,dp(60)); up.topMargin=dp(12); content.addView(use,up); use.setOnClickListener(v->showCreate());
    }

    void toggleRecording(){
        if(recording){ stopRecording(); return; }
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77); return;
        }
        recordingFile=new File(getExternalFilesDir(null),"GSR_Vocal_"+System.currentTimeMillis()+".m4a");
        recorder=new MediaRecorder(); recorder.setAudioSource(MediaRecorder.AudioSource.MIC); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setAudioEncodingBitRate(192000); recorder.setAudioSamplingRate(44100); recorder.setOutputFile(recordingFile.getAbsolutePath());
        try{ recorder.prepare(); recorder.start(); recording=true; startMs=System.currentTimeMillis(); status.setText("Recording… tap to stop"); tick(); }
        catch(Exception e){ status.setText("Could not start microphone"); }
    }
    void tick(){ if(!recording)return; long x=System.currentTimeMillis()-startMs; timer.setText(String.format("%02d:%02d.%02d",(x/60000)%60,(x/1000)%60,(x/10)%100)); handler.postDelayed(this::tick,50); }
    void stopRecording(){ try{recorder.stop();}catch(Exception ignored){} recorder.release(); recorder=null; recording=false; status.setText("Recording complete"); showRecord(); }
    void playRecording(){ try{ if(player!=null)player.release(); player=new MediaPlayer(); player.setDataSource(recordingFile.getAbsolutePath()); player.prepare(); player.start(); }catch(IOException ignored){} }

    void showCreate(){
        base("","BUILD YOUR TRACK");
        Button back=btn("‹  Back"); content.addView(back,lp(-1,dp(50))); back.setOnClickListener(v->showHome());
        TextView h=heading("What should\nit sound like?"); h.setTextSize(36);

        section("LANGUAGE");
        LinearLayout lang=new LinearLayout(this); lang.setOrientation(LinearLayout.HORIZONTAL);
        String[] ls={"Hindi","English","Hinglish"};
        for(int i=0;i<ls.length;i++){ Button b=btn(ls[i]); b.setTextSize(13); LinearLayout.LayoutParams q=lp(0,dp(56),1); if(i>0)q.leftMargin=dp(5); lang.addView(b,q); }
        content.addView(lang,lp(-1,dp(56)));

        section("STYLE");
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2); grid.setUseDefaultMargins(false);
        for(int i=0;i<styles.length;i++){
            final String s=styles[i]; Button b=btn("♪  "+s); b.setTextSize(13); b.setOnClickListener(v->{selectedStyle=s; Toast.makeText(this,s+" selected",Toast.LENGTH_SHORT).show();});
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=0; gp.height=dp(58); gp.columnSpec=GridLayout.spec(i%2,1,1f); gp.rowSpec=GridLayout.spec(i/2); gp.setMargins(i%2==0?0:dp(5),dp(4),i%2==0?dp(5):0,dp(4)); grid.addView(b,gp);
        }
        content.addView(grid,lp(-1,dp(264)));

        section("SONG IDEA  •  OPTIONAL");
        EditText idea=new EditText(this); idea.setHint("Describe your song idea…"); idea.setHintTextColor(muted); idea.setTextColor(text); idea.setTextSize(15); idea.setMinHeight(dp(96)); idea.setPadding(dp(12),dp(10),dp(12),dp(10)); idea.setGravity(Gravity.TOP); idea.setBackgroundResource(R.drawable.bg_panel); content.addView(idea,lp(-1,dp(104)));
        Button make=btn("✦  BUILD MY SONG"); make.setTextSize(15); make.setBackgroundResource(R.drawable.bg_purple); make.setTextColor(Color.WHITE); LinearLayout.LayoutParams mp=lp(-1,dp(62)); mp.topMargin=dp(14); content.addView(make,mp);
        make.setOnClickListener(v->{Toast.makeText(this,"Creating "+selectedStyle+" song…",Toast.LENGTH_SHORT).show();showStudio(idea.getText().toString());});
    }

    void showStudio(String idea){
        base("","GSR STUDIO");
        Button back=btn("‹  Back"); content.addView(back,lp(-1,dp(50))); back.setOnClickListener(v->showCreate());
        TextView h=heading(idea.length()>0?idea.toString():"My New Song"); h.setTextSize(28);
        TextView meta=tv(selectedStyle.toUpperCase()+"  •  96 BPM",10,muted); content.addView(meta,lp(-1,dp(32)));
        TextView cover=tv("GSR\n\nVOCAL + INSTRUMENTAL",26,text); cover.setGravity(Gravity.CENTER); cover.setBackgroundResource(R.drawable.bg_button); content.addView(cover,lp(-1,dp(210)));
        Button play=btn("▶   00:00        03:24"); content.addView(play,lp(-1,dp(62)));
        section("MULTI-TRACK"); addTrack("🎙  VOCAL","Your recorded voice"); addTrack("♫  MUSIC","Instrumental arrangement"); addTrack("🥁  BEAT","Drums / rhythm");
        section("MIX");
        addMixer("VOCAL",82); addMixer("MUSIC",68); addMixer("REVERB",28);
        Button ex=btn("↓  EXPORT SONG"); ex.setBackgroundResource(R.drawable.bg_purple);ex.setTextColor(Color.WHITE); content.addView(ex,lp(-1,dp(64)));
    }
    void addMixer(String label,int value){ content.addView(tv(label,10,muted),lp(-1,dp(26))); SeekBar s=new SeekBar(this); s.setProgress(value); content.addView(s,lp(-1,dp(42))); }
    void addTrack(String name,String sub){ LinearLayout x=new LinearLayout(this); x.setPadding(dp(15),dp(8),dp(15),dp(8)); x.setBackgroundResource(R.drawable.bg_panel); x.setOrientation(LinearLayout.VERTICAL); x.addView(tv(name,13,text),lp(-1,dp(28))); x.addView(tv(sub,10,muted),lp(-1,dp(24))); content.addView(x,lp(-1,dp(64))); }
    void showSongs(){ base("","YOUR PROJECTS"); TextView h=heading("Your songs"); h.setTextSize(30); content.addView(tv("No projects yet.\nCreate your first track from the Create tab.",16,muted),lp(-1,dp(80))); }
}
