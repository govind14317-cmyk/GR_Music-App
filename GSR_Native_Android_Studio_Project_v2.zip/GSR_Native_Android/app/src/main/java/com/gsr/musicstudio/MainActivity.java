package com.gsr.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(9,9,13), panel = Color.rgb(18,18,24), text = Color.rgb(247,246,250);
    private final int muted = Color.rgb(164,161,177), purple = Color.rgb(125,107,255);
    private LinearLayout root, content;
    private MediaRecorder recorder; private MediaPlayer player; private File recordingFile;
    private boolean recording = false;
    private final Handler handler = new Handler(); private long startMs;
    private TextView timer, status;
    private String selectedStyle = "Bollywood";
    private String selectedLanguage = "Hindi";
    private final String[] styles = {"Bollywood","Romantic","Sad","Rock","Lo-fi","Rap","Devotional","EDM"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
        showHome();
    }

    private TextView tv(String s, float size, int color){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setIncludeFontPadding(false);
        t.setPadding(0,0,0,0);
        return t;
    }

    // Custom text-based button avoids Android's default Button insets that were clipping labels on some phones.
    private TextView btn(String s){
        TextView b = tv(s,14,text);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(R.drawable.bg_button);
        b.setClickable(true); b.setFocusable(true);
        b.setPadding(12,8,12,8);
        b.setMinHeight(0); b.setMinimumHeight(0);
        return b;
    }

    private TextView primary(String s){
        TextView b = btn(s); b.setTextColor(Color.WHITE); b.setBackgroundResource(R.drawable.bg_purple); return b;
    }

    private void add(View v, int w, int h){ content.addView(v, new LinearLayout.LayoutParams(w,h)); }

    private void base(String subtitle){
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        root.setPadding(0,0,0,4);

        LinearLayout top = new LinearLayout(this); top.setPadding(18,10,18,6); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = tv("GSR",27,text); brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        LinearLayout brandBox = new LinearLayout(this); brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.addView(brand, new LinearLayout.LayoutParams(-1,38));
        TextView sub = tv(subtitle,8,muted); sub.setLetterSpacing(.18f); brandBox.addView(sub,new LinearLayout.LayoutParams(-1,18));
        top.addView(brandBox,new LinearLayout.LayoutParams(0,58,1));
        TextView gear = tv("⚙",23,muted); gear.setGravity(Gravity.CENTER); top.addView(gear,new LinearLayout.LayoutParams(46,58));
        root.addView(top,new LinearLayout.LayoutParams(-1,70));

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,4,16,18);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,4,8,4); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.rgb(13,13,18));
        String[] labels={"⌂\nHOME","●\nRECORD","✦\nCREATE","♫\nSONGS"};
        for(String x:labels){ TextView nb=btn(x); nb.setTextSize(11); nb.setTextColor(muted); nb.setLineSpacing(0,0.9f); nav.addView(nb,new LinearLayout.LayoutParams(0,66,1)); }
        nav.getChildAt(0).setOnClickListener(v->showHome()); nav.getChildAt(1).setOnClickListener(v->showRecord());
        nav.getChildAt(2).setOnClickListener(v->showCreate()); nav.getChildAt(3).setOnClickListener(v->showSongs());
        root.addView(nav,new LinearLayout.LayoutParams(-1,74));
        setContentView(root);
    }

    private TextView heading(String s){ TextView h=tv(s,38,text); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.setPadding(0,12,0,8); content.addView(h); return h; }
    private TextView section(String s){ TextView h=tv(s,10,muted); h.setLetterSpacing(.12f); h.setPadding(0,18,0,8); content.addView(h); return h; }

    private void showHome(){
        base("MUSIC STUDIO");
        TextView pre=tv("CREATE SOMETHING REAL",10,muted); pre.setLetterSpacing(.18f); add(pre,-1,28);
        TextView h=heading("Your voice.\nYour song."); h.setTextSize(40);
        add(tv("Record your voice and build a complete track around it.",15,muted),-1,46);
        TextView r=btn("🎙  Record a vocal\nStart a new recording"); r.setTextSize(15); r.setLineSpacing(2,1.0f); add(r,-1,76); r.setOnClickListener(v->showRecord());
        section("CREATE WITH AI");
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,0,0,0);
        TextView a=btn("✦  Make a Song\nVoice + music"), c=btn("♫  Write Lyrics\nAI songwriting");
        a.setLineSpacing(2,1.0f); c.setLineSpacing(2,1.0f);
        row.addView(a,new LinearLayout.LayoutParams(0,70,1)); row.addView(c,new LinearLayout.LayoutParams(0,70,1));
        content.addView(row); a.setOnClickListener(v->showCreate()); c.setOnClickListener(v->showCreate());
        section("RECENT PROJECTS"); add(tv("No songs yet — create your first track.",14,muted),-1,40);
    }

    private void showRecord(){
        base("GSR STUDIO");
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=btn("‹"); head.addView(back,new LinearLayout.LayoutParams(54,50)); back.setOnClickListener(v->showHome());
        TextView t=tv("VOCAL RECORDING\nGSR STUDIO",11,text); t.setGravity(Gravity.CENTER); head.addView(t,new LinearLayout.LayoutParams(0,50,1)); add(head,-1,54);
        TextView h=heading("Capture your\nvoice."); h.setTextSize(36);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(16,18,16,18); card.setBackgroundResource(R.drawable.bg_panel);
        TextView wave=tv("▁▂▃▅▇▅▃▂▁▂▃▅▇▅▃▂▁",22,purple); wave.setGravity(Gravity.CENTER); card.addView(wave,new LinearLayout.LayoutParams(-1,42));
        timer=tv("00:00.00",30,text); timer.setGravity(Gravity.CENTER); card.addView(timer,new LinearLayout.LayoutParams(-1,52));
        TextView rec=btn("●"); rec.setTextSize(30); rec.setTextColor(Color.WHITE); rec.setBackgroundResource(R.drawable.bg_record);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(88,88); rp.gravity=Gravity.CENTER; rp.topMargin=8; card.addView(rec,rp);
        status=tv("Tap to start recording",13,muted); status.setGravity(Gravity.CENTER); card.addView(status,new LinearLayout.LayoutParams(-1,38));
        add(card,-1,280); rec.setOnClickListener(v->toggleRecording());
        if(recordingFile!=null && recordingFile.exists()){ TextView play=btn("▶  Play last recording"); add(play,-1,58); play.setOnClickListener(v->playRecording()); }
        TextView use=primary("Use this vocal  →"); add(use,-1,60); use.setOnClickListener(v->showCreate());
    }

    private void toggleRecording(){
        if(recording){ stopRecording(); return; }
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77); return; }
        recordingFile=new File(getExternalFilesDir(null),"GSR_Vocal_"+System.currentTimeMillis()+".m4a");
        recorder=new MediaRecorder(); recorder.setAudioSource(MediaRecorder.AudioSource.MIC); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setAudioEncodingBitRate(192000); recorder.setAudioSamplingRate(44100); recorder.setOutputFile(recordingFile.getAbsolutePath());
        try{ recorder.prepare(); recorder.start(); recording=true; startMs=System.currentTimeMillis(); status.setText("Recording… tap to stop"); tick(); }catch(Exception e){ status.setText("Could not start microphone"); }
    }
    private void tick(){ if(!recording)return; long x=System.currentTimeMillis()-startMs; timer.setText(String.format("%02d:%02d.%02d",(x/60000)%60,(x/1000)%60,(x/10)%100)); handler.postDelayed(this::tick,50); }
    private void stopRecording(){ try{recorder.stop();}catch(Exception ignored){} recorder.release(); recorder=null; recording=false; status.setText("Recording complete"); showRecord(); }
    private void playRecording(){ try{if(player!=null)player.release(); player=new MediaPlayer(); player.setDataSource(recordingFile.getAbsolutePath()); player.prepare(); player.start();}catch(IOException ignored){} }

    private void showCreate(){
        base("BUILD YOUR TRACK");
        TextView back=btn("‹  Back"); add(back,96,48); back.setOnClickListener(v->showHome());
        TextView h=heading("What should\nit sound like?"); h.setTextSize(36);
        section("LANGUAGE");
        LinearLayout lang=new LinearLayout(this); lang.setOrientation(LinearLayout.HORIZONTAL);
        String[] ls={"Hindi","English","Hinglish"};
        for(String s:ls){ TextView b=btn(s); b.setTextSize(13); b.setOnClickListener(v->{selectedLanguage=s; updateChoiceRow(lang,s);}); lang.addView(b,new LinearLayout.LayoutParams(0,54,1)); }
        content.addView(lang); updateChoiceRow(lang,selectedLanguage);
        section("STYLE");
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2); grid.setUseDefaultMargins(false);
        for(String s:styles){ TextView b=btn("♪  "+s); b.setTextSize(13); b.setOnClickListener(v->{selectedStyle=s; Toast.makeText(this,s+" selected",Toast.LENGTH_SHORT).show();}); GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=0; gp.height=58; gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); gp.setMargins(0,3,6,3); grid.addView(b,gp); }
        content.addView(grid);
        section("SONG IDEA  •  OPTIONAL");
        EditText idea=new EditText(this); idea.setHint("Example: a motivational song about achieving dreams…"); idea.setHintTextColor(muted); idea.setTextColor(text); idea.setTextSize(15); idea.setMinHeight(86); idea.setGravity(Gravity.TOP|Gravity.START); idea.setPadding(12,12,12,12); idea.setBackgroundResource(R.drawable.bg_panel); content.addView(idea,new LinearLayout.LayoutParams(-1,92));
        TextView make=primary("✦  BUILD MY SONG"); add(make,-1,60); make.setOnClickListener(v->{Toast.makeText(this,"Creating "+selectedStyle+" song…",Toast.LENGTH_SHORT).show();showStudio(idea.getText().toString());});
    }

    private void updateChoiceRow(LinearLayout row,String selected){
        for(int i=0;i<row.getChildCount();i++){ TextView b=(TextView)row.getChildAt(i); b.setTextColor(b.getText().toString().equals(selected)?Color.WHITE:muted); b.setBackgroundResource(b.getText().toString().equals(selected)?R.drawable.bg_purple:R.drawable.bg_button); }
    }

    private void showStudio(String idea){
        base("GSR STUDIO"); TextView back=btn("‹"); add(back,54,50); back.setOnClickListener(v->showCreate());
        TextView h=heading(idea.length()>0?idea.toString():"My New Song"); h.setTextSize(27); add(tv(selectedStyle.toUpperCase()+"  •  "+selectedLanguage+"  •  96 BPM",10,muted),-1,28);
        TextView cover=tv("GSR\n\nVOCAL + INSTRUMENTAL",24,text); cover.setGravity(Gravity.CENTER); cover.setBackgroundResource(R.drawable.bg_button); add(cover,-1,190);
        add(btn("▶   00:00        03:24"),-1,58); section("MULTI-TRACK");
        addTrack("🎙  VOCAL","Your recorded voice"); addTrack("♫  MUSIC","Instrumental arrangement"); addTrack("🥁  BEAT","Drums / rhythm");
        section("MIX"); add(tv("VOCAL",10,muted),-1,22); SeekBar v=new SeekBar(this);v.setProgress(82);add(v,-1,42);
        add(tv("MUSIC",10,muted),-1,22); SeekBar m=new SeekBar(this);m.setProgress(68);add(m,-1,42);
        add(tv("REVERB",10,muted),-1,22); SeekBar rr=new SeekBar(this);rr.setProgress(28);add(rr,-1,42);
        add(primary("↓  EXPORT SONG"),-1,60);
    }
    private void addTrack(String name,String sub){ LinearLayout x=new LinearLayout(this); x.setPadding(14,8,14,8); x.setBackgroundResource(R.drawable.bg_panel); x.setOrientation(LinearLayout.VERTICAL); x.addView(tv(name,13,text),new LinearLayout.LayoutParams(-1,28)); x.addView(tv(sub,10,muted),new LinearLayout.LayoutParams(-1,22)); content.addView(x,new LinearLayout.LayoutParams(-1,64)); }
    private void showSongs(){ base("YOUR PROJECTS"); add(tv("No projects yet.",18,muted),-1,60); }
}
