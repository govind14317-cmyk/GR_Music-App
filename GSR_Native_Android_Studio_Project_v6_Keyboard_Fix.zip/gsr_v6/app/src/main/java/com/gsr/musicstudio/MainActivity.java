package com.gsr.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,8,12), PANEL=Color.rgb(19,18,28), PANEL2=Color.rgb(24,22,40);
    private final int TEXT=Color.rgb(248,247,252), MUTED=Color.rgb(151,148,164), PURPLE=Color.rgb(125,107,255), RED=Color.rgb(232,93,115);
    private LinearLayout root, content;
    private MediaRecorder recorder;
    private MediaPlayer player, studioPlayer;
    private File recordingFile;
    private boolean recording=false;
    private final Handler handler=new Handler();
    private long startMs;
    private TextView timer, recordStatus;
    private TextView studioPlay, studioTime;
    private SeekBar studioVocal, studioMusic, studioReverb;
    private long studioDurationMs=0;
    private String selectedStyle="Bollywood";
    private String selectedLanguage="Hindi";
    private final String[] styles={"Bollywood","Romantic","Sad","Rock","Lo-fi","Rap","Devotional","EDM"};
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("gsr",MODE_PRIVATE);
        setupSystemBars();
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77);
        showHome();
    }

    private void setupSystemBars(){
        Window w=getWindow();
        w.setStatusBarColor(BG); w.setNavigationBarColor(BG);
        w.getDecorView().setSystemUiVisibility(0);
        w.getDecorView().setOnApplyWindowInsetsListener((v,insets)->{
            WindowInsets.Type t=WindowInsets.Type.systemBars();
            android.graphics.Insets i=insets.getInsets(t);
            if(root!=null){ root.setPadding(root.getPaddingLeft(), i.top, root.getPaddingRight(), i.bottom); }
            return insets;
        });
    }

    private TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setFontFeatureSettings("kern");
        return t;
    }
    private TextView action(String label){
        TextView t=text(label,15,TEXT); t.setGravity(Gravity.CENTER); t.setBackgroundResource(R.drawable.bg_button); t.setClickable(true); t.setFocusable(true); t.setMinHeight(0); t.setPadding(14,0,14,0); return t;
    }
    private TextView primary(String label){
        TextView t=action(label); t.setBackgroundResource(R.drawable.bg_purple); t.setTextColor(Color.WHITE); return t;
    }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams lp(int w,int h,float weight){ return new LinearLayout.LayoutParams(w,h,weight); }
    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private void gap(int h){ Space s=new Space(this); content.addView(s,lp(1,dp(h))); }

    private void base(String subtitle){
        stopStudioPlayer();
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setClipToPadding(false);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(18),dp(8),dp(18),dp(8));
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=text("GSR",27,TEXT); logo.setTypeface(null,1); brand.addView(logo,lp(-2,dp(31)));
        TextView sub=text(subtitle,9,MUTED); sub.setLetterSpacing(.14f); brand.addView(sub,lp(-2,dp(18)));
        top.addView(brand,lp(0,dp(54))); TextView gear=text("⚙",22,MUTED); gear.setGravity(Gravity.CENTER); top.addView(gear,lp(dp(44),dp(54)));
        root.addView(top);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18),0,dp(18),dp(24));
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.setClipToPadding(false); sv.addView(content); root.addView(sv,lp(-1,0));
        LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(4),dp(5),dp(4),dp(5)); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.rgb(12,12,18));
        String[] labels={"⌂\nHOME","●\nRECORD","✦\nCREATE","♫\nSONGS"};
        for(int i=0;i<4;i++){ final int n=i; TextView b=action(labels[i]); b.setTextSize(11); b.setTextColor(MUTED); nav.addView(b,lp(0,dp(62))); b.setOnClickListener(v->{ if(n==0)showHome(); else if(n==1)showRecord(); else if(n==2)showCreate(); else showSongs();}); }
        root.addView(nav,lp(-1,dp(72)));
        // Fill remaining scroll height.
        sv.getLayoutParams().height=0; ((LinearLayout.LayoutParams)sv.getLayoutParams()).weight=1f;
        setContentView(root);
        root.requestApplyInsets();
    }

    private TextView eyebrow(String s){ TextView t=text(s,10,MUTED); t.setLetterSpacing(.20f); t.setPadding(0,dp(8),0,dp(6)); content.addView(t,lp(-1,dp(28))); return t; }
    private TextView heading(String s,float size){ TextView h=text(s,size,TEXT); h.setTypeface(null,1); h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); h.setLineSpacing(0,0.95f); content.addView(h,lp(-1,dp((int)(size*2.05)))); return h; }
    private void section(String s){ eyebrow(s); }

    private void addCard(View v,int height){ v.setBackgroundResource(R.drawable.bg_panel); content.addView(v,lp(-1,dp(height))); }

    private void showHome(){
        base("MUSIC STUDIO");
        eyebrow("CREATE SOMETHING REAL"); heading("Your voice.\nYour song.",39);
        TextView p=text("Record your voice and build a complete track around it.",15,MUTED); p.setPadding(0,0,0,dp(10)); content.addView(p,lp(-1,dp(42)));
        TextView rec=action("🎙   Record a vocal"); content.addView(rec,lp(-1,dp(58))); rec.setOnClickListener(v->showRecord());
        TextView hint=text("Start a new recording",11,MUTED); hint.setGravity(Gravity.CENTER); content.addView(hint,lp(-1,dp(22)));
        section("CREATE WITH AI");
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); content.addView(row,lp(-1,dp(72)));
        TextView make=action("✦  Make a Song"); TextView lyrics=action("♫  Write Lyrics"); row.addView(make,lp(0,dp(58),1)); row.addView(lyrics,lp(0,dp(58),1));
        make.setOnClickListener(v->showCreate()); lyrics.setOnClickListener(v->showCreate());
        section("RECENT PROJECTS");
        String last=prefs.getString("lastSong","");
        if(last.isEmpty()) content.addView(text("No songs yet — create your first track.",14,MUTED),lp(-1,dp(42)));
        else { TextView card=action("♫   "+last+"\n     Tap to open studio"); card.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); content.addView(card,lp(-1,dp(72))); card.setOnClickListener(v->showStudio(last)); }
    }

    private void showRecord(){
        base("GSR STUDIO");
        TextView back=action("‹  Back"); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); content.addView(back,lp(dp(92),dp(48))); back.setOnClickListener(v->showHome());
        eyebrow("VOCAL RECORDING"); heading("Capture your\nvoice.",36);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackgroundResource(R.drawable.bg_panel);
        TextView wave=text("▁▂▃▅▇▅▃▂▁▂▃▅▇▅▃▂▁",22,PURPLE); wave.setGravity(Gravity.CENTER); card.addView(wave,lp(-1,dp(38)));
        timer=text("00:00.00",31,TEXT); timer.setGravity(Gravity.CENTER); card.addView(timer,lp(-1,dp(48)));
        TextView rec=action("●"); rec.setTextSize(31); rec.setBackgroundResource(R.drawable.bg_record); card.addView(rec,lp(dp(94),dp(94))); ((LinearLayout.LayoutParams)rec.getLayoutParams()).gravity=Gravity.CENTER;
        recordStatus=text(recordingFile!=null&&recordingFile.exists()?"Recording ready — tap to record again":"Tap to start recording",13,MUTED); recordStatus.setGravity(Gravity.CENTER); card.addView(recordStatus,lp(-1,dp(40)));
        content.addView(card,lp(-1,dp(292))); rec.setOnClickListener(v->toggleRecording());
        if(recordingFile!=null && recordingFile.exists()){
            gap(12); TextView play=action("▶   Play last recording"); content.addView(play,lp(-1,dp(54))); play.setOnClickListener(v->playRecording());
            gap(10); TextView use=primary("Use this vocal   →"); content.addView(use,lp(-1,dp(58))); use.setOnClickListener(v->showCreate());
        }
    }

    private void toggleRecording(){
        if(recording){ stopRecording(); return; }
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},77); return; }
        recordingFile=new File(getExternalFilesDir(null),"GSR_Vocal_"+System.currentTimeMillis()+".m4a");
        recorder=new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setAudioEncodingBitRate(192000); recorder.setAudioSamplingRate(44100); recorder.setOutputFile(recordingFile.getAbsolutePath());
        try{ recorder.prepare(); recorder.start(); recording=true; startMs=System.currentTimeMillis(); recordStatus.setText("Recording… tap the button to stop"); tick(); }
        catch(Exception e){ recording=false; Toast.makeText(this,"Microphone could not start",Toast.LENGTH_LONG).show(); }
    }
    private void tick(){ if(!recording)return; long x=System.currentTimeMillis()-startMs; timer.setText(String.format("%02d:%02d.%02d",(x/60000)%60,(x/1000)%60,(x/10)%100)); handler.postDelayed(this::tick,50); }
    private void stopRecording(){ try{recorder.stop();}catch(Exception ignored){} try{recorder.release();}catch(Exception ignored){} recorder=null; recording=false; recordStatus.setText("Recording complete"); showRecord(); }
    private void playRecording(){ if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"No recording found",Toast.LENGTH_SHORT).show();return;} try{if(player!=null)player.release(); player=new MediaPlayer();player.setDataSource(recordingFile.getAbsolutePath());player.prepare();player.start();}catch(Exception e){Toast.makeText(this,"Unable to play recording",Toast.LENGTH_SHORT).show();} }

    private void showCreate(){
        base("BUILD YOUR TRACK");
        TextView back=action("‹  Back");
        back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        content.addView(back,lp(dp(92),dp(48)));
        back.setOnClickListener(v->{hideKeyboard();showHome();});

        heading("What should\nit sound like?",37);
        section("LANGUAGE");
        LinearLayout langs=new LinearLayout(this);
        langs.setOrientation(LinearLayout.HORIZONTAL);
        langs.setGravity(Gravity.CENTER);
        content.addView(langs,lp(-1,dp(64)));
        for(String s:new String[]{"Hindi","English","Hinglish"}){
            TextView b=action(s);
            langs.addView(b,lp(0,dp(52),1));
            b.setOnClickListener(v->{selectedLanguage=s;updateSelection(langs);});
        }
        updateSelection(langs);

        section("STYLE");
        for(int i=0;i<styles.length;i+=2){
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            content.addView(row,lp(-1,dp(66)));
            for(int j=i;j<i+2&&j<styles.length;j++){
                String s=styles[j];
                TextView b=action("♪  "+s);
                row.addView(b,lp(0,dp(56),1));
                b.setOnClickListener(v->{
                    selectedStyle=s;
                    Toast.makeText(this,s+" selected",Toast.LENGTH_SHORT).show();
                });
            }
        }

        section("SONG IDEA  •  OPTIONAL");
        EditText idea=new EditText(this);
        idea.setHint("Describe your song idea…");
        idea.setHintTextColor(Color.rgb(115,112,128));
        idea.setTextColor(TEXT);
        idea.setTextSize(16);
        idea.setSingleLine(false);
        idea.setMinLines(4);
        idea.setMaxLines(6);
        idea.setGravity(Gravity.TOP|Gravity.LEFT);
        idea.setPadding(dp(16),dp(14),dp(16),dp(14));
        idea.setBackgroundResource(R.drawable.bg_panel);
        idea.setImeOptions(EditorInfo.IME_ACTION_DONE);
        idea.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        content.addView(idea,lp(-1,dp(120)));

        // Keep the focused text field and Create button visible above the keyboard.
        idea.setOnFocusChangeListener((v,hasFocus)->{
            if(hasFocus){
                content.postDelayed(()->{
                    int target=Math.max(0,idea.getBottom()-dp(260));
                    ((ScrollView)content.getParent()).smoothScrollTo(0,target);
                },250);
            }
        });
        idea.setOnEditorActionListener((v,id,event)->{
            if(id==EditorInfo.IME_ACTION_DONE){
                createSongFromIdea(idea);
                return true;
            }
            return false;
        });

        gap(12);
        TextView make=primary("✦   CREATE MY SONG");
        content.addView(make,lp(-1,dp(64)));
        make.setOnClickListener(v->createSongFromIdea(idea));

        TextView note=text("You can change the language, style and song idea anytime.",11,MUTED);
        note.setGravity(Gravity.CENTER);
        content.addView(note,lp(-1,dp(40)));
        gap(30);
    }

    private void createSongFromIdea(EditText idea){
        String title=idea.getText().toString().trim();
        if(title.isEmpty()) title="My New Song";
        if(title.length()>45) title=title.substring(0,45).trim();
        prefs.edit().putString("lastSong",title).apply();
        hideKeyboard();
        idea.clearFocus();
        showStudio(title);
    }

    private void hideKeyboard(){
        try{
            InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            View v=getCurrentFocus();
            if(v!=null) imm.hideSoftInputFromWindow(v.getWindowToken(),0);
        }catch(Exception ignored){}
    }

    private void updateSelection(LinearLayout row){ for(int i=0;i<row.getChildCount();i++){TextView b=(TextView)row.getChildAt(i);String s=b.getText().toString();b.setAlpha(s.equals(selectedLanguage)?1f:.72f);} }

    private void showStudio(String title){
        base("GSR STUDIO");
        TextView back=action("‹  Back"); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); content.addView(back,lp(dp(92),dp(48))); back.setOnClickListener(v->showCreate());
        heading(title,29); TextView meta=text(selectedStyle.toUpperCase()+"  •  "+selectedLanguage+"  •  96 BPM",10,MUTED); content.addView(meta,lp(-1,dp(28)));
        LinearLayout cover=new LinearLayout(this); cover.setOrientation(LinearLayout.VERTICAL); cover.setGravity(Gravity.CENTER); cover.setBackgroundResource(R.drawable.bg_button); TextView g=text("GSR",25,TEXT);g.setGravity(Gravity.CENTER);cover.addView(g,lp(-1,dp(42)));TextView sub=text(recordingFile!=null&&recordingFile.exists()?"VOCAL READY":"RECORD A VOCAL FIRST",16,MUTED);sub.setGravity(Gravity.CENTER);cover.addView(sub,lp(-1,dp(36)));content.addView(cover,lp(-1,dp(168)));
        gap(10); studioPlay=action("▶   PLAY SONG"); content.addView(studioPlay,lp(-1,dp(58))); studioPlay.setOnClickListener(v->playStudio());
        studioTime=text("00:00 / --:--",11,MUTED);studioTime.setGravity(Gravity.CENTER);content.addView(studioTime,lp(-1,dp(28)));
        section("MULTI-TRACK"); addTrack("🎙  VOCAL","Your recorded voice",true); addTrack("♫  MUSIC","Instrumental track — add AI music next",false); addTrack("🥁  BEAT","Drums / rhythm — add AI beat next",false);
        section("MIXER"); addMixer("VOCAL",82,true); addMixer("MUSIC",68,false); addMixer("REVERB",28,false);
        gap(8); TextView ex=primary("↓   EXPORT SONG"); content.addView(ex,lp(-1,dp(60))); ex.setOnClickListener(v->exportSong(title));
    }
    private void addTrack(String name,String sub,boolean active){ LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(7),dp(14),dp(7));c.setBackgroundResource(R.drawable.bg_panel); TextView n=text(name,14,TEXT);n.setTypeface(null,1);c.addView(n,lp(-1,dp(27)));TextView s=text(sub,10,active?MUTED:Color.rgb(108,106,120));c.addView(s,lp(-1,dp(21)));content.addView(c,lp(-1,dp(64))); }
    private void addMixer(String label,int value,boolean vocal){ content.addView(text(label,10,MUTED),lp(-1,dp(22))); SeekBar s=new SeekBar(this);s.setProgress(value);content.addView(s,lp(-1,dp(36))); if(vocal)studioVocal=s; else if(studioMusic==null)studioMusic=s; else studioReverb=s; if(vocal)s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){applyStudioVolume();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}}); }

    private void playStudio(){
        if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"Record your vocal first.",Toast.LENGTH_LONG).show();return;}
        try{
            if(studioPlayer==null){ studioPlayer=new MediaPlayer(); studioPlayer.setDataSource(recordingFile.getAbsolutePath()); studioPlayer.setOnPreparedListener(mp->{studioDurationMs=mp.getDuration();applyStudioVolume();mp.start();updateStudio();}); studioPlayer.setOnCompletionListener(mp->updateStudio()); studioPlayer.prepareAsync(); studioPlay.setText("…  LOADING AUDIO"); }
            else if(studioPlayer.isPlaying()){studioPlayer.pause();updateStudio();} else {studioPlayer.start();updateStudio();}
        }catch(Exception e){Toast.makeText(this,"Unable to play song",Toast.LENGTH_SHORT).show();stopStudioPlayer();}
    }
    private void updateStudio(){ if(studioPlay==null)return; boolean playing=false;long pos=0;try{playing=studioPlayer!=null&&studioPlayer.isPlaying();if(studioPlayer!=null)pos=studioPlayer.getCurrentPosition();}catch(Exception ignored){} studioPlay.setText(playing?"❚❚   PAUSE":"▶   PLAY SONG");String a=String.format("%02d:%02d",(pos/60000)%60,(pos/1000)%60);String b=studioDurationMs>0?String.format("%02d:%02d",(studioDurationMs/60000)%60,(studioDurationMs/1000)%60):"--:--";if(studioTime!=null)studioTime.setText(a+" / "+b);if(playing)handler.postDelayed(this::updateStudio,250); }
    private void applyStudioVolume(){if(studioPlayer==null)return;try{float v=(studioVocal==null?82:studioVocal.getProgress())/100f;studioPlayer.setVolume(v,v);}catch(Exception ignored){}}
    private void stopStudioPlayer(){if(studioPlayer!=null){try{studioPlayer.stop();}catch(Exception ignored){}try{studioPlayer.release();}catch(Exception ignored){}studioPlayer=null;}}

    private void exportSong(String name){
        if(recordingFile==null||!recordingFile.exists()){Toast.makeText(this,"Please record a vocal first.",Toast.LENGTH_LONG).show();return;}
        String safe=name==null?"My New Song":name.replaceAll("[^a-zA-Z0-9 _-]","").trim();if(safe.isEmpty())safe="My New Song";String fn=safe+".m4a";
        try{
            if(android.os.Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.DISPLAY_NAME,fn);v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mp4");v.put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/GSR");Uri u=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("media file unavailable");try(InputStream in=new FileInputStream(recordingFile);OutputStream out=getContentResolver().openOutputStream(u)){byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}
            else{File dir=new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MUSIC),"GSR");dir.mkdirs();try(InputStream in=new FileInputStream(recordingFile);OutputStream out=new FileOutputStream(new File(dir,fn))){byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}
            Toast.makeText(this,"Saved in Music/GSR/"+fn,Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void showSongs(){
        base("YOUR PROJECTS"); eyebrow("RECENT PROJECTS"); String last=prefs.getString("lastSong","");
        if(last.isEmpty()){heading("No songs yet.",28);content.addView(text("Record a vocal or create your first song to see it here.",14,MUTED),lp(-1,dp(50)));}
        else{heading("Your music.",29);TextView p=action("♫   "+last+"\n     Open in GSR Studio");p.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);content.addView(p,lp(-1,dp(76)));p.setOnClickListener(v->showStudio(last));}
        gap(14);TextView rec=primary("🎙   RECORD NEW VOCAL");content.addView(rec,lp(-1,dp(58)));rec.setOnClickListener(v->showRecord());
    }

    @Override protected void onDestroy(){super.onDestroy();handler.removeCallbacksAndMessages(null);if(recording){try{recorder.stop();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}}if(player!=null)try{player.release();}catch(Exception ignored){}stopStudioPlayer();}
}
